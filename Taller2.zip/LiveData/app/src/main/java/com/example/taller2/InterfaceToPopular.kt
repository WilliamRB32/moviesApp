package com.example.taller2

import com.example.taller2.classes.MovieG

interface InterfaceToPopular {
    fun movieFromClick(movie: MovieG)

}