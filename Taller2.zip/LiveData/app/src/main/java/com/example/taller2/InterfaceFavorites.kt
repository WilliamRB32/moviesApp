package com.example.taller2

import com.example.taller2.classes.Movie
import com.example.taller2.classes.MovieG

interface InterfaceFavorites {
    fun addToFavorites(id:Long)
}