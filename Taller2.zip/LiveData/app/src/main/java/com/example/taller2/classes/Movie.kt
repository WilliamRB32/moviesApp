package com.example.taller2.classes

data class Movie(
    val name: String,
    val year: String,
    val description: String,

)